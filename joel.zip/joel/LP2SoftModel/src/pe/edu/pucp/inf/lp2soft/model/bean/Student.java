package pe.edu.pucp.inf.lp2soft.model.bean;

/**
 *
 * 
 */
public class Student {
    private int idStudent;
    private String nombre;
    private int edad;
    private float CRAEST;

    public Student(String nombre, int edad, float CRAEST) {
        this.nombre = nombre;
        this.edad = edad;
        this.CRAEST = CRAEST;
    }

    public Student() {
    }
    
    
    

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getCRAEST() {
        return CRAEST;
    }

    public void setCRAEST(float CRAEST) {
        this.CRAEST = CRAEST;
    }
    
    
    
}
