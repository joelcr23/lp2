/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.edu.pucp.inf.lp2soft.mysql;

import java.sql.Connection; // be careful
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import pe.edu.pucp.inf.lp2soft.dao.DAOStudent;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;

/**
 *
 * @author alulab14
 */
public class MySQLStudent implements DAOStudent {

    
    @Override
    public void insert(Student student) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con= DriverManager.getConnection(
            "jdbc:mysql://quilla.lab.inf.pucp.edu.pe:3306/a20161442",
            "a20161442",
            "eYx0vV");
            String sql= "INSERT INTO STUDENT(FIRST_NAME, EDAD, CRAEST) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, student.getNombre());
            ps.setInt(2, student.getEdad());
            ps.setFloat(3, student.getCRAEST());
            ps.executeUpdate();
            con.close();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }

    
    @Override
    public void update(Student student) {
        
    }

    
    @Override
    public void delete(int idStudent) {
        
    }

    
    @Override
    public ArrayList<Student> queryAll() {
       
        return new ArrayList<Student>();
    }
    
}
