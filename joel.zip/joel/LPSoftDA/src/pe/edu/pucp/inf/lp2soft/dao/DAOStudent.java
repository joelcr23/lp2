
package pe.edu.pucp.inf.lp2soft.dao;

import java.util.ArrayList;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;

/**
 *acceso a base de datos
 * SE agrega el proyecto que contiene a Student como libreria
 */
public interface DAOStudent {
    void insert(Student student);
    void update(Student student);
    void delete(int idStudent);
    ArrayList<Student> queryAll();
}
