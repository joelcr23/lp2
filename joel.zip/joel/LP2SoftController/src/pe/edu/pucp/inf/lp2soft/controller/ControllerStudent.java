/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.edu.pucp.inf.lp2soft.controller;

import pe.edu.pucp.inf.lp2soft.model.bean.Student;
import pe.edu.pucp.inf.lp2soft.mysql.MySQLStudent;

/**
 *
 * @author alulab14
 */
public class ControllerStudent {
    private Student student;
    private MySQLStudent mysqlstudent;
    
    public ControllerStudent(){
        mysqlstudent = new MySQLStudent();
        student = new Student();
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public MySQLStudent getMysqlstudent() {
        return mysqlstudent;
    }

    public void setMysqlstudent(MySQLStudent mysqlstudent) {
        this.mysqlstudent = mysqlstudent;
    }
    
    public void insert(){
        mysqlstudent.insert(student);
    }
    
}
