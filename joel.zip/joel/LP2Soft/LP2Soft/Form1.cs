﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LP2Soft
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            try
            {
                BindingList<Student> students = new BindingList<Student>();

                string cadena =
                    "server=quilla.lab.inf.pucp.edu.pe;user=a20161442;" +
                    "database=a20161442;" +
                    "port=3306;" +
                    "password=eYx0vV;";
                MySqlConnection conn =  new MySqlConnection(cadena);
                conn.Open();
                string sql = "SELECT * FROM STUDENT";
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conn;
                comando.CommandText = sql;

                MySqlDataReader reader = comando.ExecuteReader();


                while (reader.Read())
                {
                    int id = reader.GetInt32("ID_STUDENT");
                    String nombre = reader.GetString("FIRST_NAME");
                    int edad = reader.GetInt32("EDAD");
                    float craest = reader.GetFloat("CRAEST");
                    Student s = new Student (id, nombre, edad, craest);
                    students.Add(s);
                    dgvStudents.DataSource = students;
                }

                conn.Close();

            }
            catch (Exception ex)
            {

            }
        }

        
    }
}
