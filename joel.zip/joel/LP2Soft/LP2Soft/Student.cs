﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LP2Soft
{
    class Student
    {
        private int _idStudent;
        private string _firstName;
        private int _age;
        private float _CRAEST;

        public Student(int idStudent, string firstName, int age, float CRAEST)
        {
            _idStudent = idStudent;
            _firstName = firstName;
            _age = age;
            _CRAEST = CRAEST;
        }

        public int IdStudent { get => _idStudent; set => _idStudent = value; }
        public string FirstName { get => _firstName; set => _firstName = value; }
        public int Age { get => _age; set => _age = value; }
        public float CRAEST { get => _CRAEST; set => _CRAEST = value; }
    }
}
